#
# Description: Creates capsule certs
#

begin
  # ====================================
  # log beginning of method
  # ====================================

  # set method variables and log entering method
  @method = 'capsules.rb'

  # log entering method
  log(:info, "Entering sub-method <#{@method}>")

  # ====================================
  # begin main method
  # ====================================

  # log entering main method
  log(:info, "Running main portion of ruby code on method: <#{@method}>")

  # generate a url for location rest calls
  # NOTE: this is different because we arne't using katello in the url
  @rest_base_url = "https://#{@main_config[:rest_sat_server]}/api/v2/"
  foreman_oauth_key = build_rest('settings', :get, { :search => 'oauth_consumer_key'})['results'].first['value']
  foreman_oauth_secret = build_rest('settings', :get, { :search => 'oauth_consumer_secret'})['results'].first['value']

  # generate necessary capsule certificates
  @capsule_config[:capsules].each do |key,attrs|
    log(:info, "Generating capsule certificate for load-balanced capsule <#{key}>")
    log(:info, "Inspecting attrs: #{attrs.inspect}") if @debug == true

    # generate the capsule certs first
    capsule_cmd = `capsule-certs-generate \
      --capsule-fqdn #{key} \
      --certs-tar /tmp/#{key}.tar`


    if attrs[:custom_certs] == 'false'
      # generate a node command string for setting cnames
      ssl_node_cmd = ""
      attrs[:capsule_nodes].each do |node|
        log(:info, "Adding node <#{node}> to node_cmd")
        ssl_node_cmd += "--set-cname #{node} "
      end

      # run the command to generate the pulp capsule certs
      ssl_cmd_status = `/usr/bin/katello-ssl-tool --gen-server                           \
      --set-hostname #{key}                                                              \
      #{ssl_node_cmd}                                                                    \
      --server-cert #{key}-apache.crt                                                    \
      --server-cert-req #{key}-apache.crt.req                                            \
      --server-key #{key}-apache.key                                                     \
      --server-rpm #{key}-apache.rpm                                                     \
      -p file:/etc/pki/katello/private/katello-default-ca.pwd                            \
      --set-hostname #{key}                                                              \
      --set-common-name #{key}                                                           \
      --ca-cert /etc/pki/katello-certs-tools/certs/katello-default-ca.crt                \
      --ca-key /etc/pki/katello-certs-tools/private/katello-default-ca.key               \
      --set-country '#{attrs[:country]}'                                                   \
      --set-state '#{attrs[:state]}'                                                       \
      --set-city '#{attrs[:city]}'                                                         \
      --set-org '#{attrs[:org]}'                                                           \
      --set-org-unit '#{attrs[:ou]}'                                                       \
      --set-email '#{attrs[:email]}'; \
      cp /root/ssl-build/#{key}/#{key}-apache.crt #{@capsule_config[:capsule_certs_location]}; \
      cp /root/ssl-build/#{key}/#{key}-apache.key #{@capsule_config[:capsule_certs_location]}`
    end

    # run the command to generate the puppet certs
    puppet_cmd_status = `puppet cert --allow-dns-alt-names generate #{key}             \
    --dns_alt_names=#{attrs[:capsule_nodes].join(',')};                                \
    puppet cert --allow-dns-alt-names sign #{key}`

    # copy the puppet certs to /var/www/html/pub so that they can be downloaded by the capsule
    cp_cmd_status = `cp /var/lib/puppet/ssl/private_keys/#{key}.pem /var/www/html/pub/#{key}-puppet.priv; \
    cp /var/lib/puppet/ssl/public_keys/#{key}.pem /var/www/html/pub/#{key}-puppet.pub; \
    cp /var/lib/puppet/ssl/ca/signed/#{key}.pem /var/www/html/pub/#{key}-puppet.signed; \
    cp /var/lib/puppet/ssl/certs/ca.pem /var/www/html/pub/#{key}-puppet.ca`

    # ====================================
    # update parameters on location
    # ====================================

    # get the location id
    loc_id = build_rest('locations', :get, { :search => attrs[:location] })['results'].first['id']

    # log parameter creation
    log(:info, "Creating parameter capsule_lb_fqdn with value <#{key}> on location <#{attrs[:location]}> (ID #{loc_id})")

    # create the payload data
    payloads = [
      {
        :parameter => {
          :name => 'capsule_lb_fqdn',
          :value => key
        }
      },
      {
        :parameter => {
          :name => 'capsule_nodes',
          :value => attrs[:capsule_nodes].join(',')
        }
      }
    ]

    # make the rest call to create the parameters on the location
    payloads.each do |payload|
      param_response = build_rest("locations/#{loc_id}/parameters", :post, payload)
      log(:info, "Inspecting param_response: #{param_response.inspect}") if param_response

      # log an error if our location rest call failed
      log(:error, "Unable to create parameter: #{payload[:parameter][:name]}") if param_response.nil?
    end
  end

  # ====================================
  # log end of method
  # ====================================

  # log exiting method and let the parent instance know we succeeded
  log(:info, "Exiting sub-method <#{@method}>")

# set ruby rescue behavior
rescue => err
  # set error message
  message = "Error in sub-method <#{@method}>: #{err}"

  # log what we failed
  log(:error, message)
  log(:error, "[#{err}]\n#{err.backtrace.join("\n")}")

  # log exiting method and exit with MIQ_WARN status
  log(:info, "Exiting sub-method <#{@method}>")
end