#
# Description: Sets Satellite Settings
#

begin
  # ====================================
  # log beginning of method
  # ====================================

  # set method variables and log entering method
  @method = 'settings.rb'

  # log entering method
  log(:info, "Entering sub-method <#{@method}>")

  # ====================================
  # begin main method
  # ====================================

  # log entering main method
  log(:info, "Running main portion of ruby code on sub-method: <#{@method}>")

  # change the rest base url
  @rest_base_url = "https://#{@main_config[:rest_sat_server]}/api/v2/"

  build_rest('settings', :get, { :search => 'foreman_url'})

  # update satellite settings
  @set_config[:settings].each do |setting,value|
    # get the id of the setting
    set_response = build_rest('settings', :get, { :search => setting } )

    if set_response
      # get the setting id and update the setting with the value from the config
      set_id = set_response['results'].first['id']
      update_response = build_rest("settings/#{set_id}", :put, { :setting => { :value => value } })
    else
      log(:warn, "Could not find setting <#{setting}>.  Not setting value to <#{value}>")
    end
  end

  # ====================================
  # log end of method
  # ====================================

  # log exiting method and let the parent instance know we succeeded
  log(:info, "Exiting sub-method <#{@method}>")

# set ruby rescue behavior
rescue => err
  # set error message
  message = "Error in method <#{@method}>: #{err}"

  # log what we failed
  log(:error, message)
  log(:error, "[#{err}]\n#{err.backtrace.join("\n")}")

  # log exiting method and exit with MIQ_WARN status
  log(:info, "Exiting sub-method <#{@method}>")
end


