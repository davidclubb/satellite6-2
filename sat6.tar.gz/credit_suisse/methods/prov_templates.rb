#
# Description: Creates Provisioning Templates
#

begin
  # ====================================
  # log beginning of method
  # ====================================

  # set method variables and log entering method
  @method = 'prov_templates.rb'

  # log entering method
  log(:info, "Entering sub-method <#{@method}>")

  # ====================================
  # begin main method
  # ====================================

  # log entering main method
  log(:info, "Running main portion of ruby code on sub-method: <#{@method}>")

  # change the rest base url
  @rest_base_url = "https://#{@main_config[:rest_sat_server]}/api/v2/"

  # get all location ids
  loc_ids = []
  locs = build_rest('locations', :get)['results']
  locs.each { |l| loc_ids.push(l['id']) }

  # get the operating system id
  os_id = build_rest('operatingsystems', :get, { :name => @prov_config[:operating_system] } )['results'].first['id']

  # create the provisioning templates
  @prov_config[:templates].each do |type, values|
    # ====================================
    # create snippets
    # ====================================
    if type.to_s == 'snippets'
      values.each do |snippet|
        # generate the payload
        payload = {
          :provisioning_template => {
            :name => snippet,
            :snippet => true,
            :template => File.open("conf/snippets/#{snippet}").read,
            :operatingsystem_ids => [ os_id ],
            :organization_ids => [ @org_id ],
            :location_ids => loc_ids
          }
        }

        # make the rest call to create the snippet and push the id to the prov_ids array
        snippet_response = build_rest("provisioning_templates", :post, payload)
      end
    # ====================================
    # create kickstarts
    # ====================================
    elsif type.to_s == 'kickstarts'
      values.each do |kickstart|
        # generate the payload
        payload = {
          :provisioning_template => {
            :name => kickstart,
            :snippet => false,
            :template => File.open("conf/kickstarts/#{kickstart}").read,
            :operatingsystem_ids => [ os_id ],
            :template_kind_name => 'provision',
            :organization_ids => [ @org_id ],
            :location_ids => loc_ids
          }
        }

        # make the rest call to create the snippet and push the id to the prov_ids array
        ks_response = build_rest("provisioning_templates", :post, payload)

        # update the os to enable the kickstart provisioning template
        os_update = build_rest("operatingsystems/#{os_id}", :patch, { :operatingsystem => { :provisioning_template_ids => [ ks_response['id'] ] } } )
      end
    end
  end

  # ====================================
  # log end of method
  # ====================================

  # log exiting method and let the parent instance know we succeeded
  log(:info, "Exiting sub-method <#{@method}>")

# set ruby rescue behavior
rescue => err
  # set error message
  message = "Error in sub-method <#{@method}>: #{err}"

  # log what we failed
  log(:error, message)
  log(:error, "[#{err}]\n#{err.backtrace.join("\n")}")

  # log exiting method and exit with MIQ_WARN status
  log(:info, "Exiting sub-method <#{@method}>")
end


