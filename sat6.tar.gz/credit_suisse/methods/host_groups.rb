#
# Description: Creates Hostgroups
# TODO: code cleanup...lots of duplicate code
#

begin
  # ====================================
  # define methods
  # ====================================

  # method to create the hostgroup
  def hg_create(payload)
    # ensure that we have the correct rest_base_url and capture our current rest base url
    current_url = @rest_base_url
    @rest_base_url = "https://#{@main_config[:rest_sat_server]}/api/v2/"

    # post the payload
    hg_response = build_rest('hostgroups', :post, payload )
    log(:info, "Inspecting hg_response: #{hg_response.inspect}") if @debug == true

    # reset the url back to what it was before
    @rest_base_url = current_url

    # return the id of the hostgroup we created
    hg_id = hg_response['id']
  end

  # ====================================
  # log beginning of method
  # ====================================

  # set method variables and log entering method
  @method = 'host_groups.rb'

  # log entering method
  log(:info, "Entering sub-method <#{@method}>")

  # ====================================
  # set variables
  # ====================================

  # log setting variables
  log(:info, "Setting variables for sub-method: <#{@method}>")

  # ensure the rest_base_url is the default value
  @rest_base_url = "https://#{@main_config[:rest_sat_server]}#{@main_config[:rest_sat_default_suffix]}"

  # ====================================
  # begin main method
  # ====================================

  # log entering main method
  log(:info, "Running main portion of ruby code on sub-method: <#{@method}>")

  # get the environments and locations, as we will be creating them nested in the following format
  # HG_PARENT/HG_LOCATION/HG_ENV
  # NOTE: only using the last lifecycle environment in this case
  locs = @loc_config[:locations].keys.select { |loc| @loc_config[:locations][loc][:parent] == nil }
  envs = [ @env_config[:environments].keys.last ]

  # create host groups
  @hg_config[:host_groups].each do |group, attrs|
    # get the content view id
    cv_id = build_rest("content_views", :get, { :name => attrs[:content_view], :organization_id => @org_id })['results'].first['id']

    # change the rest base url for those items that aren't tenanted
    @rest_base_url = "https://#{@main_config[:rest_sat_server]}/api/v2/"

    # get the operating system id
    os_id = build_rest('operatingsystems', :get, { :name => attrs[:operating_system] } )['results'].first['id']
    os_attrs = build_rest("operatingsystems/#{os_id}", :get)
    media_id = os_attrs['media'].first['id']
    arch_id = os_attrs['architectures'].first['id']
    pt_id = os_attrs['ptables'].select { |pt| pt['name'] == attrs[:ptable]}.first['id']


    build_rest("operatingsystems/#{os_id}", :put, { :operating_system => { "os_default_templates_attributes"=>{"0"=>{"provisioning_template_id"=>"148", "template_kind_id"=>"5"} } } } )

    raise 'test'

    # create the hostgroup payload
    payload = {
      :hostgroup => {
        :name => group,
        :operatingsystem_id => os_id,
        :architecture_id => arch_id,
        :medium_id => media_id,
        :organization_ids => [ @org_id ],
        :ptable_id => pt_id
      }
    }

    # make the rest call to create the hostgroup
    hg_id = hg_create(payload)

    # ====================================
    # create location based host groups
    # ====================================
    locs.each do |loc|
      # get the location id and the object
      loc_id = build_rest('locations', :get, { :search => loc } )['results'].first['id']
      loc_obj = build_rest("locations/#{loc_id}", :get )

      # get the domain/subnet ids for the location
      domain_id = loc_obj['domains'].first['id'] rescue nil
      subnet_id = loc_obj['subnets'].first['id'] rescue nil

      # create the location based hostgroup payload
      payload = {
        :hostgroup => {
          :name => loc,
          :parent_id => hg_id,
          :location_ids => [ loc_id ],
          :organization_ids => [ @org_id ]
        }
      }

      # add the domain/subnet to the payload if we have it
      payload[:hostgroup][:domain_id] = domain_id if domain_id
      payload[:hostgroup][:subnet_id] = subnet_id  if subnet_id

      # make the rest call to create the location based hostgroup
      loc_hg_id = hg_create(payload)

      # ====================================
      # create environment based host groups
      # ====================================
      envs.each do |env|
        # reset the rest_base_url to default
        @rest_base_url = "https://#{@main_config[:rest_sat_server]}#{@main_config[:rest_sat_default_suffix]}"
        env_id = build_rest('environments', :get, { :name => env, :organization_id => @org_id } )['results'].first['id']

        # create the environment base hostgroup payload
        payload = {
          :hostgroup => {
            :name => env,
            :parent_id => loc_hg_id,
            :lifecycle_environment_id => env_id,
            :organization_ids => [ @org_id ],
            :location_ids => [ loc_id ],
            :content_view_id => cv_id
          }
        }

        # make the rest call to create the environment based hostgroup
        env_hg_id = hg_create(payload)

        # see if we have an activation key that meets the standard [:activation_key_prefix]_env and add it to the payload if we do
        ak_id = build_rest("organizations/#{@org_id}/activation_keys", :get, { :name => "#{attrs[:activation_key_prefix]}_#{env}" } )['results'].first['id'] rescue nil

        # change the rest base url and update the activation key/root password on the hostgroup if we have it
        @rest_base_url = "https://#{@main_config[:rest_sat_server]}/api/v2/"
        ak_response = build_rest("hostgroups/#{env_hg_id}/parameters", :post, { :parameter => { :name => 'kt_activation_keys', :value => "#{attrs[:activation_key_prefix]}_#{env}" } }) if ak_id
      end
    end
  end

  # ====================================
  # log end of method
  # ====================================

  # log exiting method and let the parent instance know we succeeded
  log(:info, "Exiting sub-method <#{@method}>")

# set ruby rescue behavior
rescue => err
  # set error message
  message = "Error in sub-method <#{@method}>: #{err}"

  # log what we failed
  log(:error, message)
  log(:error, "[#{err}]\n#{err.backtrace.join("\n")}")

  # log exiting method and exit with MIQ_WARN status
  log(:info, "Exiting sub-method <#{@method}>")
end


