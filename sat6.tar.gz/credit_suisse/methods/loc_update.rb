# update the locations with the new information
def loc_update(payload, loc_ids = nil)
  # get the current url
  current_url = @rest_base_url
  @rest_base_url = "https://#{@main_config[:rest_sat_server]}/api/v2/"

  # if we have location ids, update the location ids
  if loc_ids
    loc_ids.each do |loc_id|
      # put the payload on the url with the id we just got
      loc_update = build_rest("locations/#{loc_id}", :put, payload)
    end
  else
    # update all locations
    loc_response = build_rest('locations', :get)
    loc_response['results'].each do |loc|
      # get the location id
      loc_id = loc['id']

      # put the payload on the url with the id we just got
      loc_update = build_rest("locations/#{loc_id}", :put, payload)
    end
  end

  # reset the url
  @rest_base_url = current_url
end