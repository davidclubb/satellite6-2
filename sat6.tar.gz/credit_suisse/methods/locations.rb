#
# Description: Creates Satellite Locations
# TODO: code cleanup...lots of duplicate code
#

begin
  # ====================================
  # log beginning of method
  # ====================================

  # set method variables and log entering method
  @method = 'locations.rb'

  # log entering method
  log(:info, "Entering sub-method <#{@method}>")

  # ====================================
  # set variables
  # ====================================

  # log setting variables
  log(:info, "Setting variables for sub-method: <#{@method}>")

  # generate a url for location rest calls
  # NOTE: this is different because we arne't using katello in the url
  @rest_base_url = "https://#{@main_config[:rest_sat_server]}/api/v2/"

  # ====================================
  # begin main method
  # ====================================

  # log entering main method
  log(:info, "Running main portion of ruby code on sub-method: <#{@method}>")

  # create a container with our domain ids so that we can update the organization with the domain ids after we finish
  dom_ids = []

  @loc_config[:locations].each do |key, attrs|
    # ====================================
    # create domains first
    # ====================================
    unless attrs[:domain].nil?
      # check to see if we already have a domain first
      dom_check = build_rest('domains', :get, { :search => attrs[:domain] } )['results'].first['id'] rescue nil

      if dom_check.nil?
        # log domain creation
        log(:info, "Creating domain #{attrs[:domain]}")

        # create the payload data
        payload = {
            :domain => {
                :name => attrs[:domain],
                :fullname => attrs[:domain]
            }
        }

        # make the rest call to create the domain
        dom_response = build_rest('domains', :post, payload)
        log(:info, "Inspecting dom_response: #{dom_response.inspect}") if dom_response

        # log an error if our location rest call failed
        log(:error, "Unable to create domain: #{attrs[:domain]}") if dom_response.nil?

        # get the domain id for use in location creation and organization update
        dom_id = dom_response['id']
      else
        dom_id = dom_check
      end

      # push the domain id into the dom_ids array
      dom_ids.push(dom_id)
    end

    # ====================================
    # create locations last
    # ====================================

    # check to see if we already have a location first
    loc_check = build_rest('locations', :get, { :search => key } )['results'].first['id'] rescue nil

    if loc_check.nil?
      # initial logging
      log(:info, "Creating Location <#{key}>, with attributes <#{attrs}>")

      # create the payload data
      payload = {
          :location => {
              :name => key,
              :description => attrs[:description],
              :domain_ids => [ dom_id ]
          }
      }

      # add the parent id to the payload if we have it
      unless attrs[:parent].nil?
        # return the rest response
        parent_response = build_rest('locations', :get, { :search => attrs[:parent] } )
        log(:info, "Inspecting parent_response: #{parent_response.inspect}")

        # get the id from the response and add it to the payload
        parent_id = parent_response['results'].first['id']
        log(:info, "Found parent id: #{parent_id}")
        payload[:location][:parent_id] = parent_id
      end

      # make the rest call to create the location
      loc_response = build_rest('locations', :post, payload)
      log(:info, "Inspecting loc_response: #{loc_response.inspect}") if loc_response

      # log an error if our location rest call failed
      log(:error, "Unable to create location: #{key}") if loc_response.nil?

      # get the location id for later rest calls
      loc_id = loc_response['id']
    else
      loc_id = loc_check
    end

    # ====================================
    # update parameters on location
    # ====================================
    unless attrs[:params].nil?
      attrs[:params].each do |param, value|
        # log parameter creation
        log(:info, "Creating parameter <#{param}> with value <#{value}> on location <#{key}> (ID #{loc_id})")

        # create the payload data
        payload = {
            :parameter => {
                :name => param,
                :value => value
            }
        }

        # make the rest call to create the parameter on the location
        param_response = build_rest("locations/#{loc_id}/parameters", :post, payload)
        log(:info, "Inspecting param_response: #{param_response.inspect}") if param_response

        # log an error if our location rest call failed
        log(:error, "Unable to create parameter: #{param}") if param_response.nil?
      end
    end
  end

  # update the organization with the new domain ids
  org_update({ :organization => { :domain_ids => dom_ids } })

  # ====================================
  # log end of method
  # ====================================

  # log exiting method and let the parent instance know we succeeded
  log(:info, "Exiting sub-method <#{@method}>")

# set ruby rescue behavior
rescue => err
  # set error message
  message = "Error in sub-method <#{@method}>: #{err}"

  # log what we failed
  log(:error, message)
  log(:error, "[#{err}]\n#{err.backtrace.join("\n")}")

  # log exiting method and exit with MIQ_WARN status
  log(:info, "Exiting sub-method <#{@method}>")
end