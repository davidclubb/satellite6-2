#
# Description: Creates Operating Systems
# TODO: code cleanup...lots of duplicate code
#

begin
  # ====================================
  # log beginning of method
  # ====================================

  # set method variables and log entering method
  @method = 'os.rb'

  # log entering method
  log(:info, "Entering sub-method <#{@method}>")

  # ====================================
  # begin main method
  # ====================================

  # log entering main method
  log(:info, "Running main portion of ruby code on sub-method: <#{@method}>")

  # change the rest base url for those items that aren't tenanted
  @rest_base_url = "https://#{@main_config[:rest_sat_server]}/api/v2/"

  # get all location ids
  loc_ids = []
  locs = build_rest('locations', :get)['results']
  locs.each { |l| loc_ids.push(l['id']) }

  # create operating systems
  @os_config[:operating_systems].each do |os, attrs|
    # ====================================
    # create partition table first
    # ====================================
    if attrs[:ptable_conf]
      # get the partition table so that we can create it
      ptable = File.open("conf/ptables/#{attrs[:ptable_conf]}").read

      # create the partition table
      payload = {
        :ptable => {
          :name => "PT_#{os}",
          :os_family => 'Redhat',
          :layout => ptable,
          :organization_ids => [ @org_id ],
          :location_ids => loc_ids
        }
      }
      pt_response = build_rest('ptables', :post, payload )
      log(:info, "Inspecting pt_response: #{pt_response.inspect}") if @debug == true
      pt_id = pt_response['id']
    end

    # ====================================
    # create operating system
    # ====================================

    # get the architecture id to be associated with this os
    arch_id = build_rest('architectures', :get, { :search => attrs[:arch] } )['results'].first['id']

    # get the install media id to be associated with this os
    media_id = build_rest('media', :get, { :search => 'Red_Hat'})['results'].first['id']

    # ensure the media is associated with all locations/organizations
    media_response = build_rest("media/#{media_id}", :put, { :medium => { :location_ids => loc_ids, :organization_ids => [ @org_id ] } } )

    # create the os payload
    payload = {
      :operatingsystem => {
        :name => os,
        :major => attrs[:os_major],
        :minor => attrs[:os_minor],
        :description => attrs[:description],
        :family => attrs[:os_family],
        :architecture_ids => [ arch_id ],
        :medium_ids => [ media_id ],
        :ptable_ids => [ pt_id ]
      }
    }

    # make the rest call to create the os
    os_response = build_rest('operatingsystems', :post, payload)
  end

  # ====================================
  # log end of method
  # ====================================

  # log exiting method and let the parent instance know we succeeded
  log(:info, "Exiting sub-method <#{@method}>")

# set ruby rescue behavior
rescue => err
  # set error message
  message = "Error in sub-method <#{@method}>: #{err}"

  # log what we failed
  log(:error, message)
  log(:error, "[#{err}]\n#{err.backtrace.join("\n")}")

  # log exiting method and exit with MIQ_WARN status
  log(:info, "Exiting sub-method <#{@method}>")
end


