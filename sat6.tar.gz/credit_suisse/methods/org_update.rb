# update the organization with the new information
def org_update(payload)
  # ensure the rest_base_url is the default value
  current_url = @rest_base_url
  @rest_base_url = "https://#{@main_config[:rest_sat_server]}#{@main_config[:rest_sat_default_suffix]}"

  log(:info, "Updating organization <#{@org_id}> with payload <#{payload.inspect}>")
  org_response = build_rest("organizations/#{@org_id}", :put, payload)
  log(:info, "Insecting org_response: #{org_response.inspect}") if @debug == true

  # reset the rest base url
  @rest_base_url = current_url
end