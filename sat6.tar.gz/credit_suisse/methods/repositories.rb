#
# Description: Enables Red Hat repositories via REST
#

begin
  # ====================================
  # log beginning of method
  # ====================================

  # set method variables and log entering method
  @method = 'repositories.rb'

  # log entering method
  log(:info, "Entering sub-method <#{@method}>")

  # ====================================
  # set variables
  # ====================================

  # log setting variables
  log(:info, "Setting variables for sub-method: <#{@method}>")

  # ensure the rest_base_url is the default value
  @rest_base_url = "https://#{@main_config[:rest_sat_server]}#{@main_config[:rest_sat_default_suffix]}"

  # ====================================
  # begin main method
  # ====================================

  # log entering main method
  log(:info, "Running main portion of ruby code on sub-method: <#{@method}>")

  # enable the repositories
  @repo_config[:products].each do |product, repos|
    # get product id
    log(:info, "Getting product_id for product: #{product}")
    product = build_rest("organizations/#{@org_id}/products", :get, { :name => product })
    log(:info, "Inspecting product: #{product.inspect}")
    product_id = product['results'].first['id']
    raise "Unable to determine product id" if product_id.nil?

    # get the repo id and enable each repository
    repos[:repositories].each do |repo|
      repo.each do |repo_name, attrs|
        # get the repository id for the api call
        repo = build_rest("products/#{product_id}/repository_sets", :get, { :name => repo_name } )
        log(:info, "Inspecting repo: #{repo.inspect}") if @debug == true
        repo_id = repo['results'].first['id']
        raise "Unable to determine repo_id" if repo_id.nil?

        # add payload data
        payload = {}
        payload[:basearch] = attrs[:basearch] unless attrs[:basearch].nil?
        payload[:releasever] = attrs[:releasever] unless attrs[:releasever].nil?

        # enable the repository
        repo_response = build_rest("products/#{product_id}/repository_sets/#{repo_id}/enable", :put, payload ) rescue nil
        log(:info, "Inspecting repo_response: #{repo_response.inspect}")

        # log an error if the repository enable failed
        log(:error, "Unable to enable repository <#{repo_name}>") if repo_response.nil?
      end
    end

    # sync the products
    sync_response = build_rest("products/#{product_id}/sync", :post) rescue nil
    log(:info, "Inspecting sync_response: #{sync_response.inspect}") if @debug == true
    log(:error, "Unable to sync product <#{product}>") if sync_response.nil?

    # get the sync task
    task = sync_response['id']

    # wait until the sync completes
    check_task(400, 30, task)
  end

  # ====================================
  # log end of method
  # ====================================

  # log exiting method and let the parent instance know we succeeded
  log(:info, "Exiting sub-method <#{@method}>")

# set ruby rescue behavior
rescue => err
  # set error message
  message = "Error in sub-method <#{@method}>: #{err}"

  # log what we failed
  log(:error, message)
  log(:error, "[#{err}]\n#{err.backtrace.join("\n")}")

  # log exiting method and exit with MIQ_WARN status
  log(:info, "Exiting sub-method <#{@method}>")
end