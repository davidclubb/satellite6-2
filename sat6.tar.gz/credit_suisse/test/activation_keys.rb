#
# Description: Creates content views in an organization
# TODO: code cleanup...duplicating lots of code when doing composite vs standard views
#

begin
  # ====================================
  # set gem requirements
  # ====================================

  require_relative '../methods/call_rest.rb'
  require_relative '../methods/get_org_id.rb'
  require 'yaml'

  # ====================================
  # log beginning of method
  # ====================================

  # set method variables and log entering method
  @method = 'activation_keys.rb'
  @debug = true

  # ====================================
  # set variables
  # ====================================

  # log setting variables
  log(:info, "Setting variables for method: <#{@method}>")

  # get configuration
  ak_config = YAML::load_file('../conf/activation_keys.yml')
  # get configuration
  repo_config = YAML::load_file('../conf/repositories.yml')

  # inspect the repo_config
  log(:info, "Inspecting repo_config: #{repo_config.inspect}") if @debug == true

  # inspect the configs
  log(:info, "Inspecting ak_config: #{ak_config.inspect}") if @debug == true

  # ====================================
  # begin main method
  # ====================================

  # log entering main method
  log(:info, "Running main portion of ruby code on method: <#{@method}>")

  # create activation keys
  ak_config[:keys].each do |key, attrs|
    log(:info, "Activation Key: #{key}")
    log(:info, "Attrs: #{attrs.inspect}")

    # make the rest call to create the activation key
    # NOTE: content views must be available in lifecycle environments of the activation key for this to work
    # TODO: put in logic for the above NOTE
    ak_id = build_rest("organizations/#{@org_id}/activation_keys", :get, { :name => key } )['results'].first['id']

    # TODO: put in logic to update repos and subscriptions for newly created activation key
    content_response = build_rest("activation_keys/#{ak_id}/product_content", :get)['results']

    # create an array of labels that are available to the key based on subscriptions
    content_labels = []

    # push each label into an array and ensure the labels are unique
    content_response.each { |k,v| content_labels.push(k['content']['label']) }
    content_labels = content_labels.uniq

    # enable or disable the content based on our activation key configuration
    content_labels.each do |label|
      payload = {
        :content_override => {
          :content_label => label
        }
      }

      # set the correct payload value
      if attrs[:product_content][label] == 1
        # override the content to ensure the repository is enabled
        payload[:content_override][:value] = 1
      else
        # override the content to ensure the repository is disabled
        payload[:content_override][:value] = 0
      end

      # make the call to enable or disable the content
      content_response = build_rest("activation_keys/#{ak_id}/content_override", :put, payload)
    end
  end

  # ====================================
  # log end of method
  # ====================================

  # log exiting method and let the parent instance know we succeeded
  log(:info, "Exiting sub-method <#{@method}>")

# set ruby rescue behavior
rescue => err
  # set error message
  message = "Error in method <#{@method}>: #{err}"

  # log what we failed
  log(:error, message)
  log(:error, "[#{err}]\n#{err.backtrace.join("\n")}")

  # log exiting method and exit with MIQ_WARN status
  log(:info, "Exiting sub-method <#{@method}>")
end