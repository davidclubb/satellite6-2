string = "http://HOST/unattended/provision"

puts string.split('/')[2]