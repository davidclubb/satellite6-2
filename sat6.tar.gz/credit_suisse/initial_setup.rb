#
# Description: runs the initial setup
#

# ====================================
# set gem requirements
# ====================================

require 'rest-client'
require 'json'
require 'base64'
require 'yaml'

# ====================================
# define methods
# ====================================

# define log method
def log(level, msg)
  puts "[#{level}] #{@org}: #{msg}"
end

# ====================================
# set global variables
# ====================================

# turn debug on (true) or off (false)
@debug = true

# ====================================
# verify the user wants to run
# ====================================

# dialog for the user
puts "The installer will take a VERY long time to run.  This could take several hours."
puts "Are you sure you want to proceed?"
puts "y/[n]"

# get the user input
user_input = gets.chomp

# make a decision to proceed or exit based on the user input
case user_input.downcase
  when 'y', 'yes'
    log(:info, "Received input: '#{user_input}' - Proceeding with Satellite Setup")
  when 'n', 'no', '', nil
    log(:info, "Received input: '#{user_input}' - Not proceeding with Satellite Setup")
    exit 0
  else
    log(:info, "Received input: '#{user_input}' - Invalid input.  Not proceeding with Satellite Setup")
    exit 1
end

# ====================================
# load configurations
# ====================================

# load the main configuration first
@main_config = YAML::load_file('conf/main_config.yml')

# load additional configurations
@ak_config = YAML::load_file('conf/activation_keys.yml')
@capsule_config = YAML::load_file('conf/capsules.yml')
@cv_config = YAML::load_file('conf/content_views.yml')
@env_config = YAML::load_file('conf/environments.yml')
@hg_config = YAML::load_file('conf/host_groups.yml')
@loc_config = YAML::load_file('conf/locations.yml')
@org_config = YAML::load_file('conf/org.yml')
@os_config = YAML::load_file('conf/os.yml')
@prov_config = YAML::load_file('conf/prov_templates.yml')
@repo_config = YAML::load_file('conf/repositories.yml')
@set_config = YAML::load_file('conf/settings.yml')
@subscription_config = YAML::load_file('conf/subscriptions.yml')

# inspect our configs if debug is true
if @debug == true
  [ @ak_config, @cv_config, @env_config, @hg_config, @loc_config, @org_config, @os_config, @prov_config, @repo_config, @set_config, @subscription_config, @capsule_config ].each do |config|
    log(:info, "Inspecting configuration: #{config.inspect}")
  end
end

# ====================================
# load additional methods
# ====================================

require_relative 'methods/call_rest.rb'
require_relative 'methods/get_org_id.rb'
require_relative 'methods/check_task.rb'
require_relative 'methods/org_update.rb'
require_relative 'methods/loc_update.rb'

# ====================================
# run methods to setup satellite
# ====================================

#require_relative 'methods/settings.rb'
#require_relative 'methods/subscriptions.rb'
#require_relative 'methods/locations.rb'
#require_relative 'methods/repositories.rb'
#require_relative 'methods/environments.rb'
#require_relative 'methods/content_views.rb'
#require_relative 'methods/activation_keys.rb'
#require_relative 'methods/os.rb'
#require_relative 'methods/prov_templates.rb'
#require_relative 'methods/host_groups.rb'
#require_relative 'methods/capsules.rb'
